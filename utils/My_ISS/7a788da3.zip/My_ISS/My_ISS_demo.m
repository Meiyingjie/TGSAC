clc
clear
close all
P = ascread('bun000.asc');
P = P{2};
figure;
x=P(1,1:1:end);
y=P(2,(1:1:end));
z=P(3,(1:1:end));
c=z+1;
scatter3(x,y,z,1,c,'filled');
colorbar
view(2)
title('ԭʼ����')
Mdl_p = createns(P','NSMethod','kdtree','Distance','minkowski','p',2);
[idx_rn_p,dis_p]=rangesearch(Mdl_p,P',0.005);
idx_fe_p = My_ISS(P,0.005,0.8,0.4,idx_rn_p,dis_p);


figure;
x=P(1,idx_fe_p(1:1:end));
y=P(2,idx_fe_p(1:1:end));
z=P(3,idx_fe_p(1:1:end));
c=z+1;

scatter3(x,y,z,2,c,'filled');
colorbar
view(2)
title('�ؼ���ѡȡ���')
